# -*- coding: utf-8 -*-
"""
先例/挂载/括注的确定性解析 —— §九 + §十 + §2.5 可执行化。

三件事, 皆确定性、皆不裁断:
  1. 术语先例查表 (§九 + §十 裁决序): 某藏文术语是否已锁定译名? 以何为准?
  2. 括注台账判重注 (§2.5 + §三·甲.1): 某经名/人名本片是否重注? 台账缺则入待裁。
  3. 反模式闸自动化 (§五): 先例已命中的首遇术语, 自动从先例、不上呈 —— 由本层
     据挂载件自动置 precedent_hit, 不再靠手填。

§十 冲突裁决序 (高者优先, 仅裁"以何为准", 不改各级效力):
  1. 窗口内用户即时声明与裁定 (immediate_terms)
  2. 本窗口随附挂载件 (mounted_terms / annotation_ledger)
  3. §九 默认先例表 (default_precedents)
用户声明某挂载件豁免者, 该级于本窗口内不引用 (exempt_* 旗标)。
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from state_machine.states import AdjudicationType
from grading.adjudication_router import (
    AdjudicationSignals, RoutedAdjudication, route,
)


# ── 藏文键归一 (轻量, 可预期): 去空白 + 去尾随 tsheg(་)/shad(།༎) ──
# 使 "བསྐང་བ" 与 "བསྐང་བ་" 视同一词; 不做更激进的归一, 避免误合并不同词。
_TRAILING = "་།༎"  # ་ ། ༎


def _norm(s: str) -> str:
    return "".join(str(s).split()).strip(_TRAILING)


# ════════════════════════════════════════════════════════════════════════
# 术语先例 (§九 / §十)
# ════════════════════════════════════════════════════════════════════════

@dataclass
class PrecedentEntry:
    """§九 一条锁定译名。forbidden: 明令禁复现之误译 (如「守护中断」)。"""
    tib: str
    locked: str
    note: str = ""
    kind: str = "term"            # "term" | "scripture_name"
    forbidden: list = field(default_factory=list)


class TermSource(Enum):
    """某锁定译名的来源级别 (§十 裁决序)。"""
    IMMEDIATE = auto()            # 窗口即时裁定 (第1级, 最高)
    MOUNTED_LIST = auto()         # 挂载术语清单 (第2级)
    DEFAULT_PRECEDENT = auto()    # §九 默认先例表 (第3级)

    @property
    def label(self) -> str:
        return {
            TermSource.IMMEDIATE: "窗口即时裁定(§十第1级)",
            TermSource.MOUNTED_LIST: "挂载术语清单(§十第2级)",
            TermSource.DEFAULT_PRECEDENT: "§九默认先例表(§十第3级)",
        }[self]


@dataclass
class TermResolution:
    """一次术语解析结果: 已锁定则给出译名与来源级别。"""
    tib: str
    locked: str
    source: TermSource
    note: str = ""
    forbidden: list = field(default_factory=list)

    @property
    def source_label(self) -> str:
        return self.source.label


# ════════════════════════════════════════════════════════════════════════
# 括注台账 (§2.5 / §三·甲.1)
# ════════════════════════════════════════════════════════════════════════

class AnnotationStatus(Enum):
    ALREADY_ANNOTATED = auto()    # 台账载已括注 → 本片不重注
    NOT_YET_ANNOTATED = auto()    # 台账无此名 → 本片首遇, 括注一次
    UNKNOWN_NO_LEDGER = auto()    # 未挂载台账 → 窗外不可知, 入待裁 (§三·甲.1)


@dataclass
class AnnotationDecision:
    name: str
    status: AnnotationStatus
    should_annotate: Optional[bool]   # True=注 / False=不注 / None=未知须人裁
    must_adjudicate: bool             # True → 应登记为待裁项交人裁
    basis: str


# ════════════════════════════════════════════════════════════════════════
# 挂载上下文 (§十 三级 + 豁免)
# ════════════════════════════════════════════════════════════════════════

@dataclass
class MountContext:
    """
    一个窗口的外部状态视图。承载 §十 三级来源与豁免旗标, 并据 §2.5 判括注。
    本对象由窗口声明 (即时裁定 + 随附挂载件) 确定性构造, 忠于 §一 状态观:
    一切以窗口内可见/随附之声明为准, 不假设窗外记忆。
    """
    immediate_terms: dict = field(default_factory=dict)      # 藏文→译名 (第1级)
    mounted_terms: dict = field(default_factory=dict)        # 藏文→译名 (第2级)
    default_precedents: dict = field(default_factory=dict)   # 藏文→PrecedentEntry (第3级)
    annotation_ledger: Optional[set] = None                  # 已括注名单; None=未挂载
    exempt_default: bool = False
    exempt_mounted: bool = False
    exempt_ledger: bool = False

    # ── 术语查表 (§九 + §十 裁决序) ──

    @staticmethod
    def _lookup(d: dict, tib: str):
        nk = _norm(tib)
        for k, v in d.items():
            if _norm(k) == nk:
                return v
        return None

    def lookup_term(self, tib: str) -> Optional[TermResolution]:
        """
        依 §十 裁决序 (即时裁定 > 挂载清单 > §九默认) 查锁定译名。
        命中即返回 TermResolution (点名来源级别); 各级豁免则跳过; 全不命中返回 None。
        """
        # 第1级: 窗口即时裁定 (不可豁免 —— 用户当窗声明恒最高)
        v = self._lookup(self.immediate_terms, tib)
        if v is not None:
            return TermResolution(tib=tib, locked=v, source=TermSource.IMMEDIATE)
        # 第2级: 挂载术语清单
        if not self.exempt_mounted:
            v = self._lookup(self.mounted_terms, tib)
            if v is not None:
                return TermResolution(tib=tib, locked=v, source=TermSource.MOUNTED_LIST)
        # 第3级: §九 默认先例表
        if not self.exempt_default:
            e = self._lookup(self.default_precedents, tib)
            if e is not None:
                return TermResolution(tib=tib, locked=e.locked,
                                      source=TermSource.DEFAULT_PRECEDENT,
                                      note=e.note, forbidden=list(e.forbidden))
        return None

    def is_precedent_hit(self, tib: str) -> bool:
        """反模式闸用: 该词是否已在任一生效级别锁定 (→ 自动从先例, 不上呈)。"""
        return self.lookup_term(tib) is not None

    # ── 括注台账 (§2.5 + §三·甲.1) ──

    def annotation_status(self, name: str) -> AnnotationStatus:
        """
        §2.5: 已括注→不重注; 未括注→本片首遇括注一次。
        §三·甲.1: 未挂载台账者, 括注状态窗外不可知 → UNKNOWN (由调用方入待裁交人裁)。
        """
        led = None if self.exempt_ledger else self.annotation_ledger
        if led is None:
            return AnnotationStatus.UNKNOWN_NO_LEDGER
        nk = _norm(name)
        if any(_norm(x) == nk for x in led):
            return AnnotationStatus.ALREADY_ANNOTATED
        return AnnotationStatus.NOT_YET_ANNOTATED


# ════════════════════════════════════════════════════════════════════════
# 加载与构造
# ════════════════════════════════════════════════════════════════════════

def _default_precedents_path() -> str:
    return os.path.join(os.path.dirname(__file__), "..", "data", "precedents.json")


def load_default_precedents(path: Optional[str] = None) -> dict:
    """读 §九 默认先例表 JSON → {藏文: PrecedentEntry}。"""
    path = path or _default_precedents_path()
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    out = {}
    for e in raw.get("entries", []):
        out[e["tib"]] = PrecedentEntry(
            tib=e["tib"], locked=e["locked"], note=e.get("note", ""),
            kind=e.get("kind", "term"), forbidden=list(e.get("forbidden", [])),
        )
    return out


def build_mount_context(
    *,
    immediate_terms: Optional[dict] = None,
    mounted_terms: Optional[dict] = None,
    annotation_ledger: Optional[list] = None,
    precedents_path: Optional[str] = None,
    exempt_default: bool = False,
    exempt_mounted: bool = False,
    exempt_ledger: bool = False,
    load_default: bool = True,
) -> MountContext:
    """
    据窗口声明构造 MountContext。默认加载 §九 表 (未声明豁免则默认挂载, §十)。
    annotation_ledger 传 None = 未挂载台账 (→ 括注入待裁); 传 [] = 挂载了空台账
    (→ 台账内无此名即"首遇括注")。二者语义不同, 勿混。
    """
    defaults = load_default_precedents(precedents_path) if load_default else {}
    ledger = None if annotation_ledger is None else set(annotation_ledger)
    return MountContext(
        immediate_terms=dict(immediate_terms or {}),
        mounted_terms=dict(mounted_terms or {}),
        default_precedents=defaults,
        annotation_ledger=ledger,
        exempt_default=exempt_default,
        exempt_mounted=exempt_mounted,
        exempt_ledger=exempt_ledger,
    )


# ════════════════════════════════════════════════════════════════════════
# 与 adjudication_router 的桥接 (§五 反模式闸自动化)
# ════════════════════════════════════════════════════════════════════════

def signals_from_mount(
    tib: str,
    mount: MountContext,
    *,
    is_first_occurrence: bool = True,
    is_verse: bool = False,
    has_quote_marker: bool = False,
    has_variant_graph_flag: bool = False,
    is_mantra_or_seed: bool = False,
    has_scope_ambiguity_flag: bool = False,
    has_esoteric_gap_flag: bool = False,
) -> AdjudicationSignals:
    """
    据挂载件**自动**填 precedent_hit / self_verifiable_in_window, 供 route() 判。
    这正是 §五 反模式闸从"手填"变"代码强制"的接线点: 先例已命中 → 标记可自验,
    route()/check_anti_pattern 即拒其入待裁 (自动从先例, 不上呈)。
    """
    res = mount.lookup_term(tib)
    hit = res is not None
    sig = AdjudicationSignals(
        is_first_occurrence=is_first_occurrence,
        precedent_hit=hit,
        is_verse=is_verse,
        has_quote_marker=has_quote_marker,
        has_variant_graph_flag=has_variant_graph_flag,
        is_mantra_or_seed=is_mantra_or_seed,
        has_scope_ambiguity_flag=has_scope_ambiguity_flag,
        has_esoteric_gap_flag=has_esoteric_gap_flag,
    )
    if hit:
        sig.self_verifiable_in_window = True
        sig.self_verify_basis = (
            f"先例已锁定「{tib}」→「{res.locked}」({res.source_label})")
    return sig


def resolve_term_candidate(
    tib: str,
    mount: MountContext,
    *,
    is_first_occurrence: bool = True,
):
    """
    术语候选的确定性去向 (§五 + §九 + §十):
      - 先例已命中 (任一生效级别) → 返回 TermResolution: **自动从先例, 不上呈**。
      - 未命中且首遇 → 返回 RoutedAdjudication(TERM_LOCK): **真待裁, 交人裁定译名**。
    调用方 (agent/LLM) 据返回类型决定"径用先例"或"登记待裁项", 状态机不裁断译名本身。
    """
    res = mount.lookup_term(tib)
    if res is not None:
        return res
    sig = signals_from_mount(tib, mount, is_first_occurrence=is_first_occurrence)
    return route(sig)   # precedent_hit=False → TERM_LOCK 待裁 (首遇且先例未命中)


def resolve_annotation(name: str, mount: MountContext) -> AnnotationDecision:
    """
    经名/人名括注的确定性决定 (§2.5 + §三·甲.1):
      - 台账载已括注 → 不重注 (§2.5 累计)。
      - 台账无此名 → 本片首遇, 括注一次 (交付后宜增补台账)。
      - 未挂载台账 → 窗外不可知, 须入待裁交人裁 (§三·甲.1: 不责成查证窗外状态)。
    """
    st = mount.annotation_status(name)
    if st == AnnotationStatus.ALREADY_ANNOTATED:
        return AnnotationDecision(
            name=name, status=st, should_annotate=False, must_adjudicate=False,
            basis="台账载已括注 → 本片不重注 (§2.5 跨切片累计)")
    if st == AnnotationStatus.NOT_YET_ANNOTATED:
        return AnnotationDecision(
            name=name, status=st, should_annotate=True, must_adjudicate=False,
            basis="台账无此名 → 本片首遇, 括注一次并宜交付后增补台账 (§2.5)")
    return AnnotationDecision(
        name=name, status=st, should_annotate=None, must_adjudicate=True,
        basis="未挂载括注台账 → 括注状态窗外不可知, 入待裁交人裁 (§三·甲.1)")
