# -*- coding: utf-8 -*-
"""
挂载/外部状态层 (§九 先例表、§十 挂载与冲突裁决序、§2.5 括注跨切片累计)。

规范源: tibetan-chinese-collation/SKILL.md §九 / §十 / §2.5。
甲/丙方案边界: 本层是**确定性数据层** —— 把"某译名是否已锁定""某经名是否已括注"
这类**窗口内可自验的形式事实**收归代码查表, 使反模式闸「首遇但先例已命中→不上呈」
(§五) 从"靠手填 precedent_hit"变为"代码据挂载件自动判定"。

它**不做实质判定**: 译名该锁成什么、括注该怎么写、密义如何, 仍归 LLM 初判与人裁。
本层只回答"先例/台账里有没有""按 §十 裁决序以何为准", 不越权裁断。绝不接任何 API。
"""
from mounts.resolution import (
    PrecedentEntry,
    TermSource,
    TermResolution,
    AnnotationStatus,
    AnnotationDecision,
    MountContext,
    load_default_precedents,
    build_mount_context,
    resolve_term_candidate,
    resolve_annotation,
    signals_from_mount,
)

__all__ = [
    "PrecedentEntry",
    "TermSource",
    "TermResolution",
    "AnnotationStatus",
    "AnnotationDecision",
    "MountContext",
    "load_default_precedents",
    "build_mount_context",
    "resolve_term_candidate",
    "resolve_annotation",
    "signals_from_mount",
]
