#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_agent.py —— 无前端 agent 状态机入口 (拍板 A(i)/B(ii)/C(i))。

定位:
  把 collation-statemachine 落地到编程 agent 界面 (无前端)。agent 通过命令行 +
  结构化 JSON 驱动可重入 step: 每次读 ctx.json、置入本 turn 的用户信号、调一次 step、
  回写 ctx.json、打印一个 JSON StepResult 告诉 agent'现在停在哪、需要什么输入'。

三拍板落地:
  A(i) 每步整份 ctx 落盘: --ctx 指向 ctx.json; init/step 后都整份 to_dict() 写回。
  B(ii) agent 主导: 本入口不驱动对话; 它只在收到 agent 递来的用户信号后推进一步、
        由状态机校验合法性 (硬停顿/门控在 step 内经不变的 transition 强制) 并挂起。
  C(i) 结构化 JSON: --signal 收 JSON, stdout 出 JSON StepResult。机器友好、可测试。

用法:
  # 起一个直入切片, 建 ctx.json
  python run_agent.py init --ctx ctx.json --slice-id pbx30a --tone 2 --entry DIRECT

  # 推进一步 (无信号): 返回下一个 AWAIT_*
  python run_agent.py step --ctx ctx.json

  # 带信号推进: 本 turn 用户裁断 / 最终确认 (JSON)
  python run_agent.py step --ctx ctx.json --signal '{"adjudications":{"1":"A"}}'
  python run_agent.py step --ctx ctx.json --signal '{"final_confirm":true}'

信号 schema (C(i)):
  {
    "draft": true,                       # 常规入口: [draft] 到达 → 置 draft_received
    "collation_confirmed": true,         # 常规入口: 对勘表核校完成
    "silent_cache": {                    # §三1轮 静默四事缓存落 ctx (merge, 忠 §一 状态观)
      "经名锁定": [], "强制术语": [], "风险区": [],
      "节点数": 0, "声部分布": {}, "无损自检": "", "节拍预判": ""
    },
    "adjudications": {"1":"A","2":"B"},  # 待裁项 idx → 裁断选项 (裁断权属人)
    "recite": [1,2],                     # 复诵固定这些 idx (已裁者); 或 true=全部已裁项; 省略=不复诵
    "syllable_recheck": true,            # (可选) 用户明确要求偈颂音节复核 → 出稿前跑 §八 脚本
                                         #   缺省不重跑: 音节以核定/核校完成为 PASS 凭据 (§三·甲.3)
    "final_confirm": true,               # 用户"确认无误"
    "grading": [                         # (可选) 直接注入分级产出的待裁项登记
      {"idx":1,"atype":"TERM_LOCK","options":["A","B"]}
    ],
    "gates": [                           # (统稿前必备) 登记认知门控项结论
      # NODE_LOSSLESS/OUTPUT_CLEAN/SYLLABLE_COUNT 由 step 据 table_rows/final_text/
      # verse_pairs 自动核并挂证据, 无须在此登记; 其余五项 (声部排版/咒语免校/切分一贯/
      # 增量范围/A级全修) 属"认知挂证据"项, 须 agent 在此登记, 否则终核缺项无法出稿。
      {"item":"VOICE_LAYOUT","status":"PASS","evidence":"原颂顶格/论主散文/引文缩进已分层"},
      {"item":"MANTRA_EXEMPT","status":"NOT_CHECKED","exemption_reason":"本片无咒语"},
      {"item":"A_LEVEL_FIXED","status":"PASS","evidence":"A级错误已全部修正"}
      # status ∈ {PASS, SUSPECT, NOT_CHECKED}; PASS 须挂 evidence (裸PASS禁绝, §六回环3);
      # NOT_CHECKED 须注 exemption_reason (§六: 不以 PASS 占位); timing 缺省 PRE_DELIVERY。
    ]
  }

注意: 本入口只做'消费信号 → 置位 ctx → step'。真正的**认知产出** (分级报告、拟改句、
  声部/切分/A级判定) 由 agent 的 LLM 在调用本入口前完成, 经 --signal 的 grading/gates
  字段传入。状态机不产认知内容 (甲方案边界), 只据 gates 登记结论并强制裸 PASS 禁绝。
"""
from __future__ import annotations

import argparse
import json
import sys

from state_machine.states import (
    Context, Slice, Entry, AdjudicationItem, AdjudicationType,
    GateItem, GateStatus, GateTiming, GateResult,
)
from state_machine.runner import step, Handlers, StepResult
from grading.grade_contract import GradingReport, GradeContractError
from gates.gate_checks import (
    record_gate, BareGatePassError, VariantDetectionAsCoverageError,
)
from mounts import (
    build_mount_context, resolve_term_candidate, resolve_annotation,
    TermResolution,
)
from grading.adjudication_router import RoutedAdjudication


class GateSignalError(ValueError):
    """gates 信号里的 item/status/timing 名非法。"""


def _load_ctx(path: str) -> Context:
    with open(path, "r", encoding="utf-8") as f:
        return Context.from_dict(json.load(f))


def _save_ctx(path: str, ctx: Context) -> None:
    # A(i): 每步整份 ctx 落盘
    with open(path, "w", encoding="utf-8") as f:
        json.dump(ctx.to_dict(), f, ensure_ascii=False, indent=2)


def _emit(result: StepResult, ctx: Context) -> int:
    """C(i): stdout 出结构化 JSON。附最小 ctx 摘要便于 agent 组织下一 turn。"""
    out = {
        "result": result.as_json(),
        "ctx_summary": {
            "state": ctx.state.name,
            "entry": ctx.slice.entry.name,
            "adjudications": [
                {"idx": a.idx, "atype": a.atype.name,
                 "options": a.options, "resolved": a.resolved_choice,
                 "recited": a.recited}
                for a in ctx.adjudications
            ],
            "final_confirmed": ctx.final_confirmed,
            "graded_items": ctx.graded_items,
        },
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


def cmd_init(args) -> int:
    ctx = Context(slice=Slice(
        slice_id=args.slice_id,
        tone_level=args.tone,
        entry=Entry[args.entry],
    ))
    _save_ctx(args.ctx, ctx)
    print(json.dumps({
        "ok": True,
        "detail": f"已建 ctx: 切片 {args.slice_id}, 入口 {args.entry}",
        "next": "调 step 推进 (直入将挂起于 AWAIT_ADJUDICATION 或据切片而定)",
    }, ensure_ascii=False, indent=2))
    return 0


def _apply_signal(ctx: Context, sig: dict) -> None:
    """B(ii): 把 agent 递来的用户信号写进 ctx。只置位, 不做认知判断。"""
    if sig.get("draft"):
        ctx.draft_received = True
    if sig.get("collation_confirmed"):
        ctx.collation_confirmed = True
    # §三1轮 静默四事缓存落 ctx (O3): 忠 §一 状态观, 使该轮预处理状态可跨 turn 重建。
    # 自由结构 dict; merge 而非覆盖, 便于分次补全 (如先节点后节拍预判)。状态机只承载不判。
    if sig.get("silent_cache") is not None:
        ctx.silent_cache.update(sig["silent_cache"])
        ctx.log(f"[signal] 静默四事缓存已落 ctx: 键 {sorted(ctx.silent_cache)}")
    # M2 数据注入: 对勘表行 / 拟出统稿正文 (供出稿前自动核无损覆盖、洁净)
    if sig.get("table_rows") is not None:
        ctx.table_rows = [(r[0], r[1]) for r in sig["table_rows"]]
        ctx.log(f"[signal] 注入对勘表 {len(ctx.table_rows)} 行")
    if sig.get("final_text") is not None:
        ctx.final_text = sig["final_text"]
        ctx.log("[signal] 注入统稿正文")
    if sig.get("verse_pairs") is not None:
        ctx.verse_pairs = [(r[0], r[1]) for r in sig["verse_pairs"]]
        ctx.log(f"[signal] 注入偈颂 {len(ctx.verse_pairs)} 句 (供音节复核参考)")
    # §三·甲.3: 缺省音节以核定为 PASS 凭据、不重跑脚本; 唯用户明确要求复核时跑 §八 脚本。
    if sig.get("syllable_recheck"):
        ctx.syllable_recheck_requested = True
        ctx.log("[signal] 用户明确要求偈颂音节复核 (§三·甲.3): 出稿前将跑 §八 脚本, "
                "不齐句挂对照表证据待人裁 (§八 只报数不拦稿)")
    # 分级产出注入 (agent 的 LLM 已产报告, 此处仅登记待裁项)
    for g in sig.get("grading", []) or []:
        ctx.adjudications.append(AdjudicationItem(
            idx=g["idx"],
            atype=AdjudicationType[g["atype"]],
            options=list(g.get("options", [])),
        ))
        ctx.log(f"[signal] 登记待裁项 {g['idx']} ({g['atype']})")
    # A/B/C 分级报告条目注入 (认知层判定; 宽松承载, 暂不 validate_all —— 拍板: 先跑通)
    if sig.get("graded_items") is not None:
        # 注入即校验 (报告模式): 结构违规当场打回, 不留到出稿才炸。
        # 报告模式 → 允许 [N…] 式节点定位 (§三·甲4 对勘表自带编号径行沿用);
        # 统稿洁净另由出稿前 for_delivery=True 一道把关。
        report = GradingReport.from_dicts(list(sig["graded_items"]))
        report.validate_all()                      # 违规抛 GradeContractError
        ctx.graded_items = list(sig["graded_items"])
        _n = {"A": 0, "B": 0, "C": 0}
        for it in ctx.graded_items:
            g = it.get("grade", "?")
            if g in _n:
                _n[g] += 1
        ctx.log(f"[signal] 注入分级报告 A={_n['A']} B={_n['B']} C={_n['C']} (结构契约已校验)")
    # 认知门控项登记 (F1: 补齐 CLI 出稿路径)。声部排版/咒语免校/切分一贯/增量范围/
    # A级全修等五项属"认知挂证据"项, 须 agent 在此登记, 否则终核缺项无法出稿。
    # NODE_LOSSLESS/OUTPUT_CLEAN/SYLLABLE_COUNT 仍由 step 据数据自动核, 不必在此登记
    # (若在此重复登记, record_gate 会覆盖, 但通常交给 step 自动挂据更省事)。
    # 经 record_gate 登记 → 裸 PASS 禁绝 (§六回环3)、形近充覆盖禁绝 (§五) 在此仍强制。
    for g in sig.get("gates", []) or []:
        try:
            item = GateItem[g["item"]]
            status = GateStatus[g["status"]]
            timing = GateTiming[g.get("timing", "PRE_DELIVERY")]
        except KeyError as e:
            raise GateSignalError(
                f"gates 项名非法 {e}: item∈{[i.name for i in GateItem]}, "
                f"status∈{[s.name for s in GateStatus]}, "
                f"timing∈{[t.name for t in GateTiming]}"
            )
        # record_gate 强制: PASS 须挂 evidence、NOT_CHECKED 宜注 exemption_reason;
        # 违则抛 BareGatePassError/VariantDetectionAsCoverageError, 由 cmd_step 拦下不落盘。
        record_gate(ctx, timing, GateResult(
            item=item, status=status,
            evidence=str(g.get("evidence", "")),
            exemption_reason=str(g.get("exemption_reason", "")),
        ))
    # 用户裁断 (裁断权属人; 状态机只登记选择)
    for idx_str, choice in (sig.get("adjudications") or {}).items():
        idx = int(idx_str)
        for a in ctx.adjudications:
            if a.idx == idx:
                a.resolved_choice = choice
                ctx.log(f"[signal] 人裁: {idx}{choice}")
    # 复诵固定 (§七6)。契约 (F6: 消除文档与实现不符):
    #   - recite 省略  → 本 turn 不复诵 (不自动代复诵, 由 agent 明确表意)。
    #   - recite: true → 复诵**全部已裁项** ("全部已裁项"的显式写法)。
    #   - recite: [idx…] → 复诵所列 idx 中的已裁项。
    # 仅对已裁 (resolved_choice 非空) 者置 recited; 未裁者不能先复诵 (§七6 次序)。
    recite = sig.get("recite")
    if recite is not None:
        targets = ctx.adjudications if recite is True else \
            [a for a in ctx.adjudications if a.idx in recite]
        done = [a.idx for a in targets if a.resolved_choice is not None]
        for a in targets:
            if a.resolved_choice is not None:
                a.recited = True
        ctx.log(f"[signal] 复诵固定完成: {done}")
    if sig.get("final_confirm"):
        ctx.final_confirmed = True
        ctx.log("[signal] 用户最终确认")


def cmd_step(args) -> int:
    ctx = _load_ctx(args.ctx)
    sig = {}
    if args.signal:
        sig = json.loads(args.signal)
    try:
        _apply_signal(ctx, sig)
    except GradeContractError as e:
        # 结构契约打回: **不落盘** —— 违规报告不得写进 ctx, 保持真相源干净。
        print(json.dumps({
            "error": "GradeContractError",
            "detail": str(e),
            "state": ctx.state.name,
            "note": "分级报告结构违规 (§五 契约), 已拒绝注入且未落盘。"
                    "请补全结构后重发 —— 本层只校验结构, 不判分级对错。",
        }, ensure_ascii=False, indent=2), file=sys.stderr)
        return 5
    except (BareGatePassError, VariantDetectionAsCoverageError, GateSignalError) as e:
        # gates 注入违规: **不落盘** —— 裸 PASS / 形近充覆盖 / 名非法均拒绝写进 ctx。
        print(json.dumps({
            "error": type(e).__name__,
            "detail": str(e),
            "state": ctx.state.name,
            "note": "门控注入被拒 (§六裸PASS禁绝 / §五形近抽查不得充覆盖 / 名非法), "
                    "已拒绝且未落盘。请补齐 evidence 或改用 NOT_CHECKED+exemption_reason 后重发。",
        }, ensure_ascii=False, indent=2), file=sys.stderr)
        return 6
    # 本入口不产认知内容: 裁断/复诵/确认皆已由 _apply_signal 写入 ctx, step 只推进+校验。
    handlers = Handlers()
    try:
        result = step(ctx, handlers)
    except Exception as e:
        _save_ctx(args.ctx, ctx)   # 出错也落盘, 保留审计
        print(json.dumps({
            "error": type(e).__name__,
            "detail": str(e),
            "state": ctx.state.name,
            "note": "闸门/门控拦截 (B(ii): 状态机仍强制纪律)。修正信号后重试。",
        }, ensure_ascii=False, indent=2), file=sys.stderr)
        return 4
    _save_ctx(args.ctx, ctx)       # A(i): 每步整份落盘
    return _emit(result, ctx)


def _mount_from_file(path: Optional[str]):
    """
    据挂载件 JSON 构造 MountContext (§十)。schema:
      {
        "immediate_terms": {"藏文":"译名"},   # 窗口即时裁定 (第1级)
        "mounted_terms":   {"藏文":"译名"},   # 挂载术语清单 (第2级)
        "annotation_ledger": ["已注经名", ...],# 括注台账; 省略/null=未挂载 (→括注入待裁)
        "exempt_default": false,               # 豁免 §九默认表
        "exempt_mounted": false,               # 豁免挂载清单
        "exempt_ledger":  false                # 豁免台账
      }
    未给文件 → §九 默认表默认挂载、无术语清单、未挂台账。
    """
    d = {}
    if path:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    return build_mount_context(
        immediate_terms=d.get("immediate_terms"),
        mounted_terms=d.get("mounted_terms"),
        annotation_ledger=d.get("annotation_ledger"),
        exempt_default=bool(d.get("exempt_default", False)),
        exempt_mounted=bool(d.get("exempt_mounted", False)),
        exempt_ledger=bool(d.get("exempt_ledger", False)),
    )


def cmd_resolve(args) -> int:
    """
    挂载层确定性查询 (§九/§十/§2.5) —— 供无前端 agent 决定"从先例/上呈/重注否"。
    不改状态、不落盘, 只回一个 JSON 裁决。裁断权仍属人: term 未命中只是"该上呈",
    annotation 未挂台账只是"该入待裁"; 本命令不替裁。
    """
    mount = _mount_from_file(args.mounts)
    if args.kind == "term":
        out = resolve_term_candidate(args.value, mount)
        if isinstance(out, TermResolution):
            payload = {
                "kind": "term", "value": args.value, "resolved": True,
                "locked": out.locked, "source": out.source_label,
                "forbidden": list(out.forbidden),
                "action": "从先例, 不上呈 (§五 可自验)",
            }
        else:  # RoutedAdjudication
            payload = {
                "kind": "term", "value": args.value, "resolved": False,
                "atype": out.atype.name, "routing_basis": out.routing_basis,
                "action": "真待裁, 登记 grading 待裁项交人裁定译名 (§五)",
            }
    else:  # annotation
        d = resolve_annotation(args.value, mount)
        payload = {
            "kind": "annotation", "value": args.value,
            "status": d.status.name, "should_annotate": d.should_annotate,
            "must_adjudicate": d.must_adjudicate, "basis": d.basis,
        }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="run_agent.py",
                                description="无前端 agent 状态机入口 (A(i)/B(ii)/C(i))")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("init", help="建 ctx.json")
    sp.add_argument("--ctx", required=True)
    sp.add_argument("--slice-id", required=True)
    sp.add_argument("--tone", type=int, choices=[1, 2, 3], default=2,
                    help="语体等级 (§四 Level 1/2/3); 非 1/2/3 一律拒绝")
    sp.add_argument("--entry", choices=["DIRECT", "NORMAL"], default="DIRECT")
    sp.set_defaults(fn=cmd_init)

    sp = sub.add_parser("step", help="推进一步 (可带 --signal JSON)")
    sp.add_argument("--ctx", required=True)
    sp.add_argument("--signal", help="结构化 JSON 信号 (C(i))")
    sp.set_defaults(fn=cmd_step)

    sp = sub.add_parser("resolve",
                        help="挂载层确定性查询 (§九先例/§十裁决序/§2.5括注), 不改状态")
    sp.add_argument("--kind", required=True, choices=["term", "annotation"])
    sp.add_argument("--value", required=True, help="待查藏文术语 或 经名/人名")
    sp.add_argument("--mounts", help="挂载件 JSON 路径 (省略=仅 §九默认表)")
    sp.set_defaults(fn=cmd_resolve)

    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
