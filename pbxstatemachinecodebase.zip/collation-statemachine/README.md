# collation-statemachine

把 `tibetan-chinese-collation` 工作流平移进确定性状态机的可执行骨架层。

**它不改动原 SKILL。** 原 `tibetan-chinese-collation/SKILL.md` 仍是规范源；本库
只把其中确定性的轮次纪律与门控闸门显式化为代码，让流程可程序化执行、可审计。

## 一句话

状态机守纪律（不跳轮、不漏门控、裸 PASS 被拦、待裁必经人裁），
LLM 做判断（分级校对、义理、术语），人做裁断（HITL 六类诀疑）。

## 代码 ↔ 原 SKILL 条款映射

| 文件 | 实现的原 SKILL 条款 |
|------|---------------------|
| `state_machine/states.py` | §三 轮次状态集、§四 语体、§五 待裁六类、§六 八项三态 |
| `state_machine/transitions.py` | §三 轮次纪律、双入口、§七1 早停优先 |
| `state_machine/runner.py` | 全流程编排；认知工作经 Handlers 回调交 LLM |
| `gates/hard_stops.py` | §三 三个早停闸（违反=严重工作流错误） |
| `gates/gate_checks.py` | §六 八项门控、三处时机、裸PASS禁绝、§2.4 无损覆盖、§五 漏译核验 |
| `gates/syllable_check.py` | §八 音节脚本（**原样复用**，加薄封装） |
| `grading/adjudication_router.py` | §五 待裁六类形式路由 + 可自验项拒入待裁的反模式闸 |
| `grading/grade_contract.py` | §五 A/B/C 条目结构契约（B级必附改译、位置换算、漏译挂证据） |
| `mounts/resolution.py` + `data/precedents.json` | §九 先例表、§十 挂载与三级冲突裁决序、§2.5 括注跨切片累计（据挂载件自动置 `precedent_hit`、判重注） |
| `tests/` | 每条纪律一个测试 + 端到端 + grading + mounts + 集成冒烟 |

## 三个固化决定

- **拍板1 = 粗粒度**：状态机只管轮次/停顿/门控；分级校对、术语裁量等认知工作
  留 LLM 在状态内部做。状态机不替 LLM 判断。
- **拍板2 = 复用 §八脚本**：`tib_syl`/`han_len` 一字未改纳入，只加结构化封装。
- **拍板3 = 并存新建**：不动原 SKILL，本库作为其可执行骨架层。

## 运行

**CLI 用法（驱动真实切片）见 [`CLI_README.md`](CLI_README.md)** —— `run_agent.py` 的 init/step/resolve 三命令、信号 schema、门控登记、退出码与完整示例。

```bash
cd collation-statemachine
python tests/test_workflow_discipline.py    # 纪律测试
python tests/test_grading.py                # 分级契约+诀疑路由+反模式闸
python tests/test_grading_integration.py    # grading 层与状态机协同
python tests/test_end_to_end_smoke.py       # 直入切片端到端
# 或全量: python -m pytest tests/ -q       # 113 passed
```

## 细粒度层：分级脚手架 + 诀疑路由 + 反模式闸（`grading/`，甲方案）

在粗粒度状态机之上加一层**确定性约束**，把 §五 中形式可判的部分收归代码，
**不碰实质判定**：

- **诀疑路由**：候选待裁项依形式特征（引文标记 / 先例命中 / 各类旗标）确定性
  分派到六类之一。
- **反模式闸**（§五核心）：窗口内可自验之项（括注状态已定、术语首遇但先例已命中）
  被**禁止**包装成待裁上呈——代码强制，命中即抛错。
- **分级契约**：B级必附推荐改译、A级漏译必挂节点比对证据、位置必换算为对勘表编号。
  不合规打回，但不判定分级实质对错。

"这是不是误译""归哪类"的实质判断仍由 LLM 初判，本层只校验其输出合法、并把
形式路由与反模式拦截确定性化。

## 挂载/外部状态层（`mounts/` + `data/`，丙方案）

把 §九 先例表、§十 挂载与冲突裁决序、§2.5 括注跨切片累计**收归独立数据文件 + 查表逻辑**，
使反模式闸「首遇但先例已命中→不上呈」从"靠手填 `precedent_hit`"变为"据挂载件自动判定"：

- **§九 先例表**：`data/precedents.json`（藏文→锁定译名，含禁复现误译如「守护中断」）。
- **§十 三级冲突裁决序**：窗口即时裁定 > 挂载术语清单 > §九默认表；用户声明豁免则跳过该级。
  `MountContext.lookup_term` 依此序返回锁定译名并点名来源级别。
- **§2.5 + §三·甲.1 括注**：`annotation_status` 三态——台账载已注→不重注；台账无→首遇注；
  **未挂台账→窗外不可知，入待裁交人裁**（`None` 未挂载 与 `[]` 空台账语义不同，勿混）。
- **反模式自动化**：`resolve_term_candidate` 先例命中→返回 `TermResolution`（不上呈）；
  未命中→返回 `RoutedAdjudication(TERM_LOCK)`（真待裁）。桥接既有 `route()`/反模式闸，不另起炉灶。

CLI 查询（不改状态、不落盘，只回 JSON 裁决）：

```bash
python run_agent.py resolve --kind term --value "ཚོགས་ཀྱི་འཁོར་ལོ"      # → 从先例:荟供轮
python run_agent.py resolve --kind annotation --value "某经名" --mounts m.json  # → 重注否/入待裁
```

边界：本层只回答"先例/台账里有没有、按裁决序以何为准"，**不裁断**译名该锁成什么、括注该怎么写——那仍归 LLM 初判与人裁。绝不接任何 API。

## 三个硬停顿（代码强制，不依赖自觉）

1. draft 前禁任何翻译输出（§三1轮，最高优先级）
2. 核校完成前禁分级报告/统稿（§三2轮）
3. 磋商不可省，直入亦然：GRADING→DELIVERY 必经 磋商→复诵→全裁→最终确认（§三·甲5）

## 门控（§六）

八项 × 三态（PASS须挂证据 / SUSPECT / NOT_CHECKED），三处时机。
**裸 PASS 在代码层抛错**——报 PASS 必须挂可核产物，对应 §六回环3
"要么挂证据报 PASS，要么承认未核"。

## 认知/确定性分界

确定性（状态机）：轮次推进、硬停顿、门控闸门、物理核验（无损覆盖/漏译/tsheg·CJK 计数）。
认知（LLM，状态内）：A/B/C 分级、义理、句式判断。
人裁（HITL）：术语锁定、引文偈成例、底本正字、密义。

## 未做（留后续）

- 常规入口四步节奏（静默轮→对勘表轮）已在 `step` 编排并测（`test_normal_entry`）；剩认知内容仍由人工/LLM 在挂起点填。
- 声部排版、切分一贯、增量范围、A级全修等认知门控项的**自动**证据产出仍待补，现由 agent 经 `gates` 信号挂 LLM 证据（统稿洁净、无损覆盖、音节已确定性化）。
- 挂载件（先例/台账/术语清单）跨 turn 持久化（落 ctx 序列化）——当前需随窗口声明重新提供（忠于 §一 状态观）。
