# -*- coding: utf-8 -*-
"""
F3/F4 —— 挂载/外部状态层 (§九 先例表 · §十 挂载与冲突裁决序 · §2.5 括注台账)。

坐实这层把三条纪律从"靠自觉/手填"变"代码据挂载件确定性判定":
  1. §九 默认先例表可加载, 条目齐。
  2. §十 冲突裁决序: 即时裁定 > 挂载清单 > §九默认; 豁免则跳过该级。
  3. §五 反模式闸自动化: 先例已命中的首遇术语, resolve_term_candidate 返回 TermResolution
     (自动从先例、不上呈); 未命中才返回 TERM_LOCK 待裁。
  4. §2.5 + §三·甲.1 括注: 台账载已注→不重注; 台账无→首遇注; 未挂台账→入待裁。
"""
from __future__ import annotations

import sys
import os

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mounts import (
    PrecedentEntry, TermSource, TermResolution,
    AnnotationStatus, AnnotationDecision, MountContext,
    load_default_precedents, build_mount_context,
    resolve_term_candidate, resolve_annotation, signals_from_mount,
)
from grading.adjudication_router import (
    RoutedAdjudication, AntiPatternRejection, route,
)
from state_machine.states import AdjudicationType


# ── §九 默认先例表 ──

def test_default_precedents_load():
    """§九 表可加载, 关键条目齐 (荟供轮 / 遮护障碍 / 圆满)。"""
    p = load_default_precedents()
    assert "ཚོགས་ཀྱི་འཁོར་ལོ" in p
    assert p["ཚོགས་ཀྱི་འཁོར་ལོ"].locked == "荟供轮"
    # 禁复现误译登记
    assert "守护中断" in p["བར་ཆད་བསྲུང་བ"].forbidden
    assert p["ཁམས་གསུམ་ཟིལ་གནོན"].kind == "scripture_name"


def test_default_precedent_hit_via_mount():
    """§九 词经 build_mount_context 默认挂载 → 命中, 来源=第3级。"""
    m = build_mount_context()
    r = m.lookup_term("མཐིང་ནག")
    assert r is not None and r.locked == "绀黑色"
    assert r.source == TermSource.DEFAULT_PRECEDENT


def test_trailing_tsheg_normalized():
    """尾随 tsheg 归一: 「བསྐང་བ་」应命中「བསྐང་བ」。"""
    m = build_mount_context()
    assert m.lookup_term("བསྐང་བ་") is not None
    assert m.is_precedent_hit("བསྐང་བ")


# ── §十 冲突裁决序 ──

def test_resolution_order_immediate_beats_all():
    """同词三级皆有 → 即时裁定 (第1级) 胜。"""
    m = build_mount_context(
        immediate_terms={"མཐིང་ནག": "即时译名"},
        mounted_terms={"མཐིང་ནག": "挂载译名"},
    )
    r = m.lookup_term("མཐིང་ནག")
    assert r.locked == "即时译名"
    assert r.source == TermSource.IMMEDIATE


def test_resolution_order_mounted_beats_default():
    """挂载清单 (第2级) 胜 §九默认 (第3级)。"""
    m = build_mount_context(mounted_terms={"མཐིང་ནག": "挂载译名"})
    r = m.lookup_term("མཐིང་ནག")
    assert r.locked == "挂载译名"
    assert r.source == TermSource.MOUNTED_LIST


def test_exempt_default_skips_ninth_table():
    """豁免 §九默认表 → 该级不引用, 仅默认表有的词变为未命中。"""
    m = build_mount_context(exempt_default=True)
    assert m.lookup_term("མཐིང་ནག") is None       # §九 有, 但被豁免
    # 但挂载清单仍生效
    m2 = build_mount_context(mounted_terms={"མཐིང་ནག": "挂载译名"}, exempt_default=True)
    assert m2.lookup_term("མཐིང་ནག").source == TermSource.MOUNTED_LIST


def test_exempt_mounted_skips_mounted_list():
    """豁免挂载清单 → 跳过第2级, 落到 §九默认。"""
    m = build_mount_context(
        mounted_terms={"མཐིང་ནག": "挂载译名"}, exempt_mounted=True)
    r = m.lookup_term("མཐིང་ནག")
    assert r.source == TermSource.DEFAULT_PRECEDENT and r.locked == "绀黑色"


# ── §五 反模式闸自动化 ──

def test_precedent_hit_term_not_escalated():
    """
    §五 核心: 先例已命中的首遇术语 → resolve_term_candidate 返回 TermResolution,
    自动从先例、**不上呈**。这条从"手填 precedent_hit"变为"代码据挂载件自动判"。
    """
    m = build_mount_context()
    out = resolve_term_candidate("ཚོགས་ཀྱི་འཁོར་ལོ", m, is_first_occurrence=True)
    assert isinstance(out, TermResolution)
    assert out.locked == "荟供轮"


def test_precedent_miss_term_becomes_term_lock():
    """先例未命中的首遇术语 → 真待裁 (TERM_LOCK), 交人裁定译名。"""
    m = build_mount_context()
    out = resolve_term_candidate("གསར་པའི་ཐ་སྙད", m, is_first_occurrence=True)
    assert isinstance(out, RoutedAdjudication)
    assert out.atype == AdjudicationType.TERM_LOCK


def test_signals_from_mount_triggers_anti_pattern():
    """
    signals_from_mount 对先例命中词自动置 self_verifiable → route() 拒之 (反模式)。
    证明桥接确实驱动既有反模式闸, 而非另起炉灶。
    """
    m = build_mount_context()
    sig = signals_from_mount("ཕྱོགས་སྐྱོང་བ", m, is_first_occurrence=True)
    assert sig.precedent_hit is True
    assert sig.self_verifiable_in_window is True
    with pytest.raises(AntiPatternRejection):
        route(sig)


# ── §2.5 + §三·甲.1 括注台账 ──

def test_annotation_already_in_ledger_not_reannotated():
    """台账载已括注 → 不重注 (§2.5 累计)。"""
    m = build_mount_context(annotation_ledger=["གཤིན་རྗེ་ཆོས་ཀྱི་རྒྱལ་པོ"])
    d = resolve_annotation("གཤིན་རྗེ་ཆོས་ཀྱི་རྒྱལ་པོ", m)
    assert d.status == AnnotationStatus.ALREADY_ANNOTATED
    assert d.should_annotate is False and d.must_adjudicate is False


def test_annotation_not_in_ledger_first_occurrence():
    """台账挂载但无此名 → 本片首遇, 括注一次。"""
    m = build_mount_context(annotation_ledger=["某已注经名"])
    d = resolve_annotation("新经名", m)
    assert d.status == AnnotationStatus.NOT_YET_ANNOTATED
    assert d.should_annotate is True and d.must_adjudicate is False


def test_annotation_no_ledger_goes_to_adjudication():
    """
    §三·甲.1: 未挂载台账 → 括注状态窗外不可知, 入待裁交人裁。
    注意 None (未挂载) 与 [] (挂载空台账) 语义不同。
    """
    m = build_mount_context(annotation_ledger=None)
    d = resolve_annotation("任一经名", m)
    assert d.status == AnnotationStatus.UNKNOWN_NO_LEDGER
    assert d.should_annotate is None and d.must_adjudicate is True


def test_empty_ledger_is_not_unknown():
    """挂载了空台账 [] → 台账内无此名即"首遇括注", 不等于"未挂载"。"""
    m = build_mount_context(annotation_ledger=[])
    d = resolve_annotation("任一经名", m)
    assert d.status == AnnotationStatus.NOT_YET_ANNOTATED


def test_exempt_ledger_reverts_to_unknown():
    """豁免台账 → 即便传了名单也按"未挂载"处理 (§十 豁免)。"""
    m = build_mount_context(
        annotation_ledger=["གཤིན་རྗེ་ཆོས་ཀྱི་རྒྱལ་པོ"], exempt_ledger=True)
    d = resolve_annotation("གཤིན་རྗེ་ཆོས་ཀྱི་རྒྱལ་པོ", m)
    assert d.status == AnnotationStatus.UNKNOWN_NO_LEDGER


# ── CLI 接线 (run_agent.py resolve) ──

def _resolve_cli(kind, value, mounts_path=None):
    import json as _json
    import subprocess
    repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cmd = [sys.executable, os.path.join(repo, "run_agent.py"),
           "resolve", "--kind", kind, "--value", value]
    if mounts_path:
        cmd += ["--mounts", mounts_path]
    p = subprocess.run(cmd, cwd=repo, capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    return _json.loads(p.stdout)


def test_cli_resolve_term_precedent_hit():
    """CLI: §九 命中词 → resolved=True, 从先例不上呈。"""
    out = _resolve_cli("term", "ཚོགས་ཀྱི་འཁོར་ལོ")
    assert out["resolved"] is True and out["locked"] == "荟供轮"


def test_cli_resolve_annotation_no_ledger_adjudicate():
    """CLI: 未挂台账 → must_adjudicate=True (§三·甲.1)。"""
    out = _resolve_cli("annotation", "某经名")
    assert out["status"] == "UNKNOWN_NO_LEDGER" and out["must_adjudicate"] is True


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
