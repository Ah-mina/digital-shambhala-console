# -*- coding: utf-8 -*-
"""
F1 回归锁 —— CLI (run_agent.py) 必须能把直入切片一路驱动到 DONE。

背景 (审计 F1):
  run_agent.py 是本项目"平移到编程 agent (无前端)"的**主交付面**。八项终核门控里,
  NODE_LOSSLESS/OUTPUT_CLEAN/SYLLABLE_COUNT 由 step 据数据自动核; 其余五项 (声部排版/
  咒语免校/切分一贯/增量范围/A级全修) 属"认知挂证据"项, 须 agent 经 --signal 登记。
  修复前 --signal **没有**登记门控结论的字段 → verify_pre_delivery_complete 必抛
  "统稿前终核缺项", CLI 永远跑不到 DELIVERY/DONE。

  本测试经真实子进程驱动 CLI, 证明 gates 信号补上后可跑到 DONE; 并证明裸 PASS 门控
  注入仍被拦 (§六回环3), 且被拒的注入不落盘 (真相源干净)。

  一律不改原 SKILL、不改既有测试; 只新增回归锁。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile

import pytest

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_AGENT = os.path.join(_REPO, "run_agent.py")


def _run(ctx_path: str, signal: dict | None = None) -> tuple[int, dict, str]:
    """跑一次 run_agent.py step; 返回 (returncode, stdout_json_or_{}, stderr)。"""
    cmd = [sys.executable, _AGENT, "step", "--ctx", ctx_path]
    if signal is not None:
        cmd += ["--signal", json.dumps(signal, ensure_ascii=False)]
    p = subprocess.run(cmd, cwd=_REPO, capture_output=True, text=True)
    out = {}
    if p.stdout.strip():
        try:
            out = json.loads(p.stdout)
        except json.JSONDecodeError:
            pass
    return p.returncode, out, p.stderr


def _init(ctx_path: str) -> None:
    p = subprocess.run(
        [sys.executable, _AGENT, "init", "--ctx", ctx_path,
         "--slice-id", "pbx-cli-f1", "--tone", "2", "--entry", "DIRECT"],
        cwd=_REPO, capture_output=True, text=True,
    )
    assert p.returncode == 0, f"init 失败: {p.stderr}"


# 五项认知门控 + 音节豁免 (本片无偈颂) 的完整登记信号 —— 修复前无处可传。
_FULL_GATES = [
    {"item": "VOICE_LAYOUT", "status": "PASS", "evidence": "原颂顶格/论主散文/引文缩进已分层"},
    {"item": "MANTRA_EXEMPT", "status": "NOT_CHECKED", "exemption_reason": "本片无咒语"},
    {"item": "SEGMENTATION_CONSISTENT", "status": "PASS", "evidence": "切分与声部一贯"},
    {"item": "LAYOUT_INCREMENTAL", "status": "PASS", "evidence": "增量交付, 藏文为锚, 未全篇重出"},
    {"item": "A_LEVEL_FIXED", "status": "PASS", "evidence": "A级错误已全部修正"},
    {"item": "SYLLABLE_COUNT", "status": "NOT_CHECKED", "exemption_reason": "本片无偈颂"},
]


def test_cli_drives_direct_slice_to_done():
    """
    F1 主张: 修复后 CLI 能把直入切片驱动到 DONE。
    step1 → AWAIT_FINAL_CONFIRM (无待裁项直落此点);
    step2 (final_confirm + 五认知门控 + 数据) → AWAIT_DELIVERY (终核放行);
    step3 → AWAIT_GATE_REPORT (§六统稿后回环);
    step4 → DONE。
    """
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _init(ctx)

        rc, out, err = _run(ctx)
        assert rc == 0, err
        assert out["result"]["signal"] == "AWAIT_FINAL_CONFIRM", out

        rc, out, err = _run(ctx, {
            "final_confirm": True,
            "table_rows": [["བཀྲ་ཤིས་བདེ་ལེགས།", "吉祥安乐"]],
            "final_text": "吉祥安乐",
            "gates": _FULL_GATES,
        })
        assert rc == 0, err
        assert out["result"]["signal"] == "AWAIT_DELIVERY", out

        rc, out, err = _run(ctx)
        assert rc == 0, err
        assert out["result"]["signal"] == "AWAIT_GATE_REPORT", out

        rc, out, err = _run(ctx)
        assert rc == 0, err
        assert out["result"]["signal"] == "DONE", out
        assert out["ctx_summary"]["state"] == "DONE"


def test_cli_bare_pass_gate_rejected_and_not_persisted():
    """
    F1 不得削弱 §六回环3: 经 gates 注入的裸 PASS (PASS 无 evidence) 仍须当场拒绝,
    且被拒注入**不落盘** —— ctx 的 gate_results 保持为空。
    """
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _init(ctx)
        _run(ctx)  # 推进到 AWAIT_FINAL_CONFIRM

        rc, out, err = _run(ctx, {
            "gates": [{"item": "VOICE_LAYOUT", "status": "PASS", "evidence": ""}],
        })
        assert rc == 6, f"裸PASS门控注入应以 exit 6 被拒, 实得 {rc}; stderr={err}"
        assert "BareGatePassError" in err

        # 未落盘: 磁盘上的 ctx 门控结论仍为空
        with open(ctx, encoding="utf-8") as f:
            disk = json.load(f)
        assert disk["gate_results"] == [], f"被拒注入不应落盘, 实得 {disk['gate_results']}"


def test_cli_bad_gate_name_rejected():
    """gates 项 item/status 名非法 → GateSignalError, exit 6, 明示合法值。"""
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _init(ctx)
        _run(ctx)

        rc, out, err = _run(ctx, {
            "gates": [{"item": "NONSENSE", "status": "PASS", "evidence": "x"}],
        })
        assert rc == 6, err
        assert "GateSignalError" in err


# ── F7: --tone 仅 1/2/3 ──

def test_cli_tone_out_of_range_rejected():
    """F7: --tone 非 1/2/3 → argparse 拒绝 (§四 只有 Level 1/2/3)。"""
    import subprocess
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        p = subprocess.run(
            [sys.executable, _AGENT, "init", "--ctx", ctx,
             "--slice-id", "x", "--tone", "5", "--entry", "DIRECT"],
            cwd=_REPO, capture_output=True, text=True)
        assert p.returncode != 0
        assert "invalid choice" in p.stderr and "--tone" in p.stderr


# ── F6: recite 契约 (省略=不复诵 / true=全部已裁 / [idx]=所列已裁) ──

def _two_item_ctx_at_adjudication(ctx):
    _init(ctx)
    _run(ctx, {"grading": [
        {"idx": 1, "atype": "TERM_LOCK", "options": ["A", "B"]},
        {"idx": 2, "atype": "SCOPE_AMBIGUITY", "options": ["A", "B"]},
    ]})


def _recited_map(out):
    return {a["idx"]: a["recited"] for a in out["ctx_summary"]["adjudications"]}


def test_cli_recite_true_recites_all_resolved():
    """recite:true → 全部已裁项复诵固定。"""
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _two_item_ctx_at_adjudication(ctx)
        rc, out, err = _run(ctx, {"adjudications": {"1": "A", "2": "B"}, "recite": True})
        assert rc == 0, err
        assert _recited_map(out) == {1: True, 2: True}


def test_cli_recite_list_recites_only_listed():
    """recite:[1] → 仅 idx1 复诵; idx2 未复诵 → 仍挂 AWAIT_RECITE。"""
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _two_item_ctx_at_adjudication(ctx)
        rc, out, err = _run(ctx, {"adjudications": {"1": "A", "2": "B"}, "recite": [1]})
        assert rc == 0, err
        assert _recited_map(out) == {1: True, 2: False}
        assert out["result"]["signal"] == "AWAIT_RECITE"


def test_cli_recite_omitted_does_not_recite():
    """recite 省略 → 不复诵 (F6: 不自动代复诵); 裁毕仍停在 AWAIT_RECITE。"""
    with tempfile.TemporaryDirectory() as d:
        ctx = os.path.join(d, "ctx.json")
        _two_item_ctx_at_adjudication(ctx)
        rc, out, err = _run(ctx, {"adjudications": {"1": "A", "2": "B"}})
        assert rc == 0, err
        assert _recited_map(out) == {1: False, 2: False}
        assert out["result"]["signal"] == "AWAIT_RECITE"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
