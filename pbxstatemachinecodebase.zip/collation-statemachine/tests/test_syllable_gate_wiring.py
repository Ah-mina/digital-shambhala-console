# -*- coding: utf-8 -*-
"""
SYLLABLE_COUNT 接线测试 —— §八 音节脚本接进 step 实运行路径。

背景 (对照实验发现): check_pairs 早已实现且测过, 但**未接进 step 自动核验路径**,
SYLLABLE_COUNT 门控仍靠 handler 手挂 PASS —— 与 M2 之前的处境同类。
本步补 ctx.verse_pairs + record_syllable_count + 接进 step 两处自动核点。

本测试证明 (record_syllable_count = 脚本层, 供"用户明确要求复核"时用):
  1. 全齐偈颂 → 脚本 PASS, 挂逐句对照表为物理证据
  2. 不齐句 → 脚本 SUSPECT, 且**强制挂 tsheg 逐段证据**(禁裸归因, §八失信防线)
  3. 合法逸出句(17/19/21言)不误报为不齐
  4. 无 verse_pairs 时不伪造 PASS, 抛 BareGatePassError
  5. verse_pairs 经 to_dict/from_dict 无损往返

F2 修正后的 step 层行为 (见文末两测试):
  - 缺省 (直入/常规均, 无复核请求): 音节以核定/核校完成为 PASS 凭据, **不重跑脚本**
    (§三·甲.3); 即便注入的 verse_pairs 有不齐句, 也不重核、不 SUSPECT。
  - 用户明确要求复核 (syllable_recheck_requested): 跑脚本, 不齐句 SUSPECT+证据 **surfaced**,
    但**不硬拦出稿** (§八 只报数不拦稿; §2.2 逸出句不触发人工) —— 交统稿后回环人裁。
  注: 音节 SUSPECT 不拦稿是 SYLLABLE_COUNT 专属例外; 其余七项 SUSPECT 照旧阻断 (如漏译致
      NODE_LOSSLESS SUSPECT 仍拦, 见 test_m2_lossless_wiring)。
"""
from __future__ import annotations

import sys
import os

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from state_machine.states import (
    Context, Slice, Entry, GateItem, GateTiming, GateStatus,
)
from gates.gate_checks import record_syllable_count, BareGatePassError

# pbx30a N05 真实偈颂 (含合法逸出句 17/19/17/21)
_N05 = [
    ("སྒྲིབ་བྲལ་མཁའ་དབྱིངས་རྩོལ་རྟོག་མཚན་མའི་རྡུལ་གྱིས་གོ་སྐབས་ནམ་ཡང་མི་ཕྱེད་ཀྱང་",
     "离垢虚空虽永不为勤作分别相尘所分割"),
    ("མ་རུངས་གདུལ་དཀའི་ཡུལ་ལ་རང་བཞིན་ཤུགས་ཀྱི་ཐུགས་རྗེས་འབར་བའི་ཕྱག་རྒྱ་རང་ཤར་བ",
     "于难调伏凶恶境中自然大悲威光手印自显现"),
    ("དུས་མཐའི་མེ་ལྕེ་བྱེ་བའི་སྟོབས་ཀྱིས་སྲིད་དང་ཉོན་མོངས་ཚང་ཚིང་ཡུད་ལ་སྲེག",
     "末劫千万火舌威力刹那焚尽生死烦恼林"),
    ("བདུད་འདུལ་ཧེ་རུ་ཀ་དཔལ་སངས་རྒྱས་ཀུན་གྱི་ཕྲིན་ལས་རྫོགས་མཛད་ལྷག་པའི་ལྷ་མཆོག་དེས་སྐྱོངས་ཤིག",
     "降魔吉祥赫鲁迦尊圆满诸佛一切事业胜本尊祈护"),
]
# pbx30a N07-1: 对勘表两层措辞不一致处 —— Layer A 作9字, 藏文8段 → 应判不齐
_N07_1_LAYER_A = ("རྩོད་པའི་དུས་མཐར་ཨུ་དུམྦཱ་ར་ལྟར", "争斗时末犹如优昙华")
_N07_1_LAYER_B = ("རྩོད་པའི་དུས་མཐར་ཨུ་དུམྦཱ་ར་ལྟར", "争斗末世如优昙华")


def _ctx(pairs):
    c = Context(slice=Slice(slice_id="v", tone_level=2, entry=Entry.NORMAL))
    c.verse_pairs = pairs
    return c


def test_aligned_verses_auto_pass_with_evidence():
    """全齐偈颂(含合法逸出17/19/17/21) → PASS, 逸出句不误报。"""
    ctx = _ctx(_N05)
    r = record_syllable_count(ctx, GateTiming.PRE_DELIVERY)
    assert r.status == GateStatus.PASS, f"合法逸出句被误判不齐: {r.evidence}"
    assert r.evidence.strip(), "PASS 必须挂证据 (禁裸 PASS)"
    assert "4句全齐" in r.evidence


def test_misaligned_verse_suspect_with_segment_evidence():
    """
    不齐句 → SUSPECT, 且必挂 tsheg 逐段证据。
    用例取自真实对勘表 pbx30a 句9 (Layer A 措辞9字 vs 藏文8段)。
    §八: 只报哪侧超出+逐段明细, 不裁定该改哪侧 —— 那归人裁。
    """
    ctx = _ctx([_N07_1_LAYER_A])
    r = record_syllable_count(ctx, GateTiming.PRE_DELIVERY)
    assert r.status == GateStatus.SUSPECT
    # 必须点明哪侧超出
    assert "han_surplus" in r.evidence
    # 必须挂逐段物理证据 (禁裸归因)
    assert "逐段" in r.evidence and "tsheg" in r.evidence
    assert "藏8/汉9" in r.evidence


def test_layer_b_wording_is_aligned():
    """同一句 Layer B 措辞(8字)则齐 —— 证明差异源于汉译措辞, 非脚本判错。"""
    ctx = _ctx([_N07_1_LAYER_B])
    r = record_syllable_count(ctx, GateTiming.PRE_DELIVERY)
    assert r.status == GateStatus.PASS


def test_no_verse_pairs_refuses_bare_pass():
    """无偈颂数据 → 不伪造 PASS, 须显式豁免登记 (§六)。"""
    ctx = _ctx([])
    with pytest.raises(BareGatePassError):
        record_syllable_count(ctx, GateTiming.PRE_DELIVERY)


def test_verse_pairs_roundtrip():
    """A(i): verse_pairs 经序列化无损往返, 还原为元组。"""
    ctx = _ctx(_N05)
    revived = Context.from_dict(ctx.to_dict())
    assert revived.verse_pairs == _N05
    assert all(isinstance(p, tuple) for p in revived.verse_pairs)


def _drive_to_final_confirm(ctx):
    """把 ctx 推到 FINAL_CONFIRM, 并手挂除三项自动核外的五项 PASS, 供 step 出稿。"""
    from state_machine.states import State, GateResult
    from state_machine.transitions import initial_state, transition
    from gates.gate_checks import record_gate

    ctx.table_rows = [("藏", "汉")]
    ctx.final_text = "统稿"
    initial_state(ctx)
    ctx.log("[step] on_grading 已执行")
    transition(ctx, State.CONSULTATION)
    ctx.consultation_done = True
    transition(ctx, State.ADJUDICATION_RECITE)
    ctx.final_confirmed = True
    transition(ctx, State.FINAL_CONFIRM)
    # NODE_LOSSLESS/OUTPUT_CLEAN/SYLLABLE_COUNT 由 step 自动核, 其余五项手挂 PASS
    for item in GateItem:
        if item in (GateItem.NODE_LOSSLESS, GateItem.OUTPUT_CLEAN,
                    GateItem.SYLLABLE_COUNT):
            continue
        record_gate(ctx, GateTiming.PRE_DELIVERY,
                    GateResult(item=item, status=GateStatus.PASS, evidence="e"))


def test_direct_mode_syllable_ratified_not_reverified():
    """
    F2 主张 (§三·甲.3): 直入模式下音节以"输入即核定"为 PASS 凭据, **不重跑脚本**。
    即便注入的 verse_pairs 含不齐句, step 也不得重核判 SUSPECT, 更不得据此拦稿。
    终核放行 → AWAIT_DELIVERY; SYLLABLE_COUNT 记 PASS, 证据点名"核定凭据"。
    """
    from state_machine import runner as runner_mod

    ctx = Context(slice=Slice(slice_id="v", tone_level=2, entry=Entry.DIRECT))
    ctx.verse_pairs = [_N07_1_LAYER_A]           # 不齐, 但直入不重核
    _drive_to_final_confirm(ctx)

    r = runner_mod.step(ctx, runner_mod.Handlers())
    assert r.signal == runner_mod.StepSignal.AWAIT_DELIVERY, (
        f"直入未要求复核, 音节应以核定凭据放行, 实得 {r.signal}")
    syl = ctx.gate_results[(GateTiming.PRE_DELIVERY, GateItem.SYLLABLE_COUNT)]
    assert syl.status == GateStatus.PASS, "直入音节应以核定为 PASS 凭据, 不重核判 SUSPECT"
    assert "核定" in syl.evidence and "未重跑" in syl.evidence


def test_syllable_recheck_surfaces_suspect_but_does_not_block():
    """
    F2 主张 (§八 只报数不拦稿 / §2.2 逸出句不触发人工): 用户明确要求复核时, 跑脚本、
    不齐句挂 SUSPECT+逐段证据 **surfaced**, 但**不硬拦出稿** —— 逸出句 vs 真不齐归人裁。
    终核仍放行 → AWAIT_DELIVERY; SYLLABLE_COUNT 记 SUSPECT 且挂 tsheg 逐段证据。
    """
    from state_machine import runner as runner_mod

    ctx = Context(slice=Slice(slice_id="v", tone_level=2, entry=Entry.DIRECT))
    ctx.verse_pairs = [_N07_1_LAYER_A]           # 不齐 (藏8/汉9)
    ctx.syllable_recheck_requested = True         # 用户明确要求复核
    _drive_to_final_confirm(ctx)

    r = runner_mod.step(ctx, runner_mod.Handlers())
    assert r.signal == runner_mod.StepSignal.AWAIT_DELIVERY, (
        f"音节存疑不得拦稿 (§八), 应放行至 AWAIT_DELIVERY, 实得 {r.signal}")
    syl = ctx.gate_results[(GateTiming.PRE_DELIVERY, GateItem.SYLLABLE_COUNT)]
    assert syl.status == GateStatus.SUSPECT, "复核发现不齐应 surfaced 为 SUSPECT"
    assert "逐段" in syl.evidence and "藏8/汉9" in syl.evidence, "SUSPECT 须挂逐段物理证据"


def test_non_syllable_suspect_still_blocks():
    """
    回归护栏: 音节 SUSPECT 不拦稿是 SYLLABLE_COUNT 专属例外; 其余项 SUSPECT 照旧阻断。
    此处令 NODE_LOSSLESS 因漏译(空汉译行)自动判 SUSPECT → 终核仍须阻断出稿。
    """
    from state_machine import runner as runner_mod
    from state_machine.states import State, GateResult
    from state_machine.transitions import initial_state, transition
    from gates.gate_checks import record_gate

    ctx = Context(slice=Slice(slice_id="v", tone_level=2, entry=Entry.DIRECT))
    ctx.table_rows = [("藏1", "汉1"), ("藏2", "")]   # 第2行漏译 → NODE_LOSSLESS SUSPECT
    ctx.final_text = "统稿"
    initial_state(ctx)
    ctx.log("[step] on_grading 已执行")
    transition(ctx, State.CONSULTATION)
    ctx.consultation_done = True
    transition(ctx, State.ADJUDICATION_RECITE)
    ctx.final_confirmed = True
    transition(ctx, State.FINAL_CONFIRM)
    for item in GateItem:
        if item in (GateItem.NODE_LOSSLESS, GateItem.OUTPUT_CLEAN):
            continue
        # 无偈颂 → 显式豁免 SYLLABLE_COUNT (F1: agent 据实登记)
        if item == GateItem.SYLLABLE_COUNT:
            record_gate(ctx, GateTiming.PRE_DELIVERY, GateResult(
                item=item, status=GateStatus.NOT_CHECKED,
                exemption_reason="本片无偈颂"))
            continue
        record_gate(ctx, GateTiming.PRE_DELIVERY,
                    GateResult(item=item, status=GateStatus.PASS, evidence="e"))

    with pytest.raises(RuntimeError) as ei:
        runner_mod.step(ctx, runner_mod.Handlers())
    assert "存疑" in str(ei.value) or "SUSPECT" in str(ei.value)
    assert "节点序列无损覆盖" in str(ei.value), "阻断应指向漏译致的 NODE_LOSSLESS, 非音节"


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
