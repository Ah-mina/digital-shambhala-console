# `run_agent.py` — 对勘状态机 CLI 用法

无前端 agent 驱动对勘工作流的命令行入口。每次调用**读 ctx → 置入信号 → 推进一步 → 回写 ctx → 打印 JSON**，告诉你"现在停在哪、需要什么"。全部状态在 `--ctx` 那个 JSON 里，随时可查、可续、可跨 turn 恢复。

设计原则：**状态机守纪律**（轮次、硬停顿、门控），**LLM/你做认知判断**（分级、拟改译），**人做裁断**（待裁六类）。CLI 只消费信号、推进、校验——**不产认知内容、不裁断、不接任何网络/API**。

---

## 0. 前置

```bash
cd collation-statemachine          # 须在此目录运行 (模块路径)
python3 --version                  # 3.10+
```
无三方依赖运行主流程；跑测试需 `pip install pytest`。

---

## 1. 三个子命令

| 命令 | 作用 |
|---|---|
| `init` | 建一个切片的 `ctx.json` |
| `step` | 推进一步（可带 `--signal` JSON），返回下一个 `AWAIT_*` 或 `DONE` |
| `resolve` | 挂载层确定性查询（先例/括注），**不改状态、不落盘** |

### `init`
```bash
python run_agent.py init --ctx pbx30x.json --slice-id pbx30x --tone 2 --entry NORMAL
```
| 参数 | 说明 |
|---|---|
| `--ctx` | ctx 文件路径（进度存盘） |
| `--slice-id` | 切片编号 |
| `--tone` | 语体等级，仅 `1`/`2`/`3`（§四；越界拒绝） |
| `--entry` | `DIRECT`（直入，豁免前两轮）或 `NORMAL`（常规四步） |

### `step`
```bash
python run_agent.py step --ctx pbx30x.json                       # 无信号推进
python run_agent.py step --ctx pbx30x.json --signal '{...}'      # 带信号推进
```
输出 JSON：`result.signal`（当前挂起点）、`result.detail`、`result.pending`（待办 idx），加 `ctx_summary` 摘要。

### `resolve`
```bash
python run_agent.py resolve --kind term       --value "ཚོགས་ཀྱི་འཁོར་ལོ"
python run_agent.py resolve --kind annotation  --value "某经名" --mounts m.json
```
见 [§6 挂载层查询](#6-挂载层查询-resolve)。

---

## 2. 状态流与挂起信号

```
常规入口(NORMAL):  SILENT_INTAKE ─AWAIT_DRAFT→ COLLATION_TABLE ─AWAIT_COLLATION→ ┐
直入入口(DIRECT):  ────────────（豁免前两轮，输入即核定）──────────────────────→ GRADING
                                                                                 │
  GRADING ─AWAIT_ADJUDICATION→ CONSULTATION → ADJUDICATION_RECITE ─AWAIT_RECITE→ │
  → FINAL_CONFIRM ─AWAIT_FINAL_CONFIRM→ DELIVERY ─AWAIT_DELIVERY→ (出稿)
  → GATE_REPORT ─AWAIT_GATE_REPORT→ DONE
```

| 信号 | 含义 / 你要回填什么 |
|---|---|
| `AWAIT_DRAFT` | 常规入口静默轮：等 `[draft]`（闸1：收稿前禁译）。可趁此注入 `silent_cache` |
| `AWAIT_COLLATION` | 常规入口对勘表轮：对勘表已出，等 `collation_confirmed`（闸2） |
| `AWAIT_ADJUDICATION` | 待裁项需人裁（填 `adjudications`） |
| `AWAIT_RECITE` | 已裁未复诵固定（`recite`，§七6） |
| `AWAIT_FINAL_CONFIRM` | 等 `final_confirm`（闸3） |
| `AWAIT_DELIVERY` | 终核已放行，等出统稿（`final_text`）；再 `step` 即出稿 |
| `AWAIT_GATE_REPORT` | 统稿已出，门控回报八项状态；再 `step` 即 `DONE` |
| `DONE` | 流程完成 |

**可重入契约**：`step` 幂等于挂起点（条件未满足则返回同一 `AWAIT_*`，不重跑已完成的认知步）；全状态在 ctx 内，落盘-读回可无缝恢复。

---

## 3. 信号 schema（`--signal` 里能填什么）

一次 `step` 可同时带多个字段。所有字段皆可选。

| 字段 | 形态 | 用途 / 生效轮次 |
|---|---|---|
| `draft` | `true` | 常规入口：`[draft]` 到达（闸1） |
| `silent_cache` | `{…}` | 静默四事缓存落 ctx（**merge**，可分次补；§三1轮，忠 §一 状态观） |
| `collation_confirmed` | `true` | 常规入口：对勘表核校完成（闸2） |
| `table_rows` | `[[藏,汉],…]` | 对勘表行；供出稿前**自动**核无损覆盖/漏译 |
| `verse_pairs` | `[[藏句,汉句],…]` | 偈颂逐句；供音节门控 |
| `syllable_recheck` | `true` | 明确要求偈颂音节**脚本复核**；缺省不重跑（音节以核定为 PASS 凭据，§三·甲.3） |
| `grading` | `[{idx,atype,options}]` | 登记待裁项（见 §4） |
| `graded_items` | `[{…}]` | A/B/C 分级条目，**注入即结构校验**（见 §4） |
| `adjudications` | `{"1":"A","2":"B"}` | 人裁：待裁 idx → 选项（裁断权属人） |
| `recite` | `[1,2]` 或 `true` | 复诵固定所列 idx（已裁者）；`true`=全部已裁；省略=不复诵 |
| `final_confirm` | `true` | 用户"确认无误"（闸3） |
| `final_text` | `"…"` | 统稿正文；供出稿前**自动**核洁净 |
| `gates` | `[{…}]` | 登记认知门控项结论（见 §5） |

---

## 4. 分级与待裁（第三轮）

**待裁六类**（`grading` 的 `atype`）：
`VARIANT_GRAPH`（形近异文）· `ESOTERIC_GAP`（密义存疑）· `TERM_LOCK`（术语锁定）· `SCOPE_AMBIGUITY`（辖域两可）· `QUOTE_PRECEDENT`（引文成例）· `MANTRA_BORDERLINE`（咒语归属）。

```json
{"grading":[{"idx":1,"atype":"TERM_LOCK","options":["A《事业游戏》","B《事业游舞》"]}]}
```
登记后 `step` 挂 `AWAIT_ADJUDICATION`；五项全裁前闸3不放行。

**A/B/C 分级条目**（`graded_items`，注入即校验 §五 契约，违规当场打回、**不落盘**）：

| 字段 | 必填？ |
|---|---|
| `grade` | 是（`A`/`B`/`C`） |
| `location` | 是（对勘表编号；报告态允许 `[N…]` 式） |
| `problem` | 是 |
| `tibetan_collation` | 是 |
| `recommended_fix` | **B 级必填**；A/C 视情 |
| `draft_original` | C 级若出更正则必填（成"初稿→更正"对照） |
| `is_omission` / `omission_evidence` | A 级漏译须挂节点比对证据 |

> C 级**禁列**偈颂字数/节拍/逸出句/偶言句——另有通道（§2.2、§八、排版附注），契约层会拦。

---

## 5. 门控登记（出稿前必备）

终核要求**八项**齐备。三项**确定性**的由 `step` 自动核并挂证据，**无须**在 `gates` 里登记：

| 自动项 | 触发数据 |
|---|---|
| `NODE_LOSSLESS` | `table_rows`（行完整+逐行有汉译） |
| `OUTPUT_CLEAN` | `final_text`（无节点编号/声部名/批注） |
| `SYLLABLE_COUNT` | `verse_pairs`（缺省以核校完成为 PASS 凭据；`syllable_recheck` 时跑脚本，不齐句 SUSPECT 但**不拦稿**，§八） |

其余**五项**属认知判断，须经 `gates` 登记你的结论：
`VOICE_LAYOUT` · `SEGMENTATION_CONSISTENT` · `LAYOUT_INCREMENTAL` · `A_LEVEL_FIXED` · `MANTRA_EXEMPT`

```json
{"gates":[
  {"item":"VOICE_LAYOUT","status":"PASS","evidence":"引文缩进/论主顶格，未混层"},
  {"item":"A_LEVEL_FIXED","status":"PASS","evidence":"A级已全修"},
  {"item":"MANTRA_EXEMPT","status":"NOT_CHECKED","exemption_reason":"本片无咒语"}
]}
```
- `status` ∈ `PASS`（**须挂 `evidence`** 物理证据，否则**裸 PASS 禁绝**当场打回）/ `SUSPECT`（阻断出稿，音节除外）/ `NOT_CHECKED`（**须注 `exemption_reason`**，不得以 PASS 占位）。
- `timing` 缺省 `PRE_DELIVERY`。

> **红线**：`gates` 登记的是你（认知层）已下的结论+证据；代码只登记并强制裸 PASS 禁绝，**绝不替你判**。

---

## 6. 挂载层查询 `resolve`

据 §九 先例表、你随附的挂载件、§十 裁决序，**确定性**回一个裁决（不改状态、不落盘）。

```bash
# 术语：命中先例→从先例不上呈；未命中→真待裁(TERM_LOCK)
python run_agent.py resolve --kind term --value "ཚོགས་ཀྱི་འཁོར་ལོ"           # → 荟供轮(§九)
# 括注：台账载已注→不重注；无→首遇注；未挂台账→入待裁(§三·甲.1)
python run_agent.py resolve --kind annotation --value "某经名" --mounts m.json
```

挂载件 `m.json`（字段皆可省）：
```json
{"immediate_terms":{"藏文":"当场定的译名"},
 "mounted_terms":{"藏文":"随附清单译名"},
 "annotation_ledger":["已在先前切片括注过的经名"],
 "exempt_default":false,"exempt_mounted":false,"exempt_ledger":false}
```
裁决序（高者先）：`immediate_terms` > `mounted_terms` > §九默认表；某级 `exempt_*` 即跳过。
`annotation_ledger` 传 `null`/省略 = 未挂台账（→入待裁）；传 `[]` = 空台账（→首遇注）——语义不同，勿混。

---

## 7. 退出码

| 码 | 含义 |
|---|---|
| `0` | 成功（stdout 出 JSON StepResult / resolve 结果） |
| `4` | 闸门/门控拦截（如终核缺项、SUSPECT 阻断）；已落盘保留审计 |
| `5` | `graded_items` 结构违规（§五契约）；**未落盘** |
| `6` | `gates` 注入违规（裸 PASS / 形近充覆盖 / 名非法）；**未落盘** |

被拒（5/6）的信号不写进 ctx，真相源保持干净——修正后重发即可。

---

## 8. 完整示例

### 8.1 直入（最短路径，无待裁项）
```bash
python run_agent.py init --ctx s.json --slice-id pbx-x --tone 2 --entry DIRECT
python run_agent.py step --ctx s.json                                    # → AWAIT_FINAL_CONFIRM
python run_agent.py step --ctx s.json --signal '{
  "final_confirm":true,
  "table_rows":[["藏","汉"]], "final_text":"（统稿）",
  "gates":[
    {"item":"VOICE_LAYOUT","status":"PASS","evidence":"分层"},
    {"item":"SEGMENTATION_CONSISTENT","status":"PASS","evidence":"一贯"},
    {"item":"LAYOUT_INCREMENTAL","status":"PASS","evidence":"增量藏文为锚"},
    {"item":"A_LEVEL_FIXED","status":"PASS","evidence":"A级已修"},
    {"item":"MANTRA_EXEMPT","status":"NOT_CHECKED","exemption_reason":"无咒语"},
    {"item":"SYLLABLE_COUNT","status":"NOT_CHECKED","exemption_reason":"本片无偈颂"}
  ]}'                                                                     # → AWAIT_DELIVERY
python run_agent.py step --ctx s.json                                    # → AWAIT_GATE_REPORT
python run_agent.py step --ctx s.json                                    # → DONE
```

### 8.2 常规（完整四步，带待裁）
```bash
python run_agent.py init --ctx n.json --slice-id pbx-n --tone 2 --entry NORMAL
python run_agent.py step --ctx n.json                                    # → AWAIT_DRAFT
python run_agent.py step --ctx n.json --signal '{"silent_cache":{"节点数":71,"无损自检":"PASS"}}'   # 仍 AWAIT_DRAFT，四事已落盘
python run_agent.py step --ctx n.json --signal '{"draft":true,"table_rows":[["藏1","汉1"],["藏2","汉2"]],"verse_pairs":[["藏句","汉句"]]}'   # → AWAIT_COLLATION
python run_agent.py step --ctx n.json --signal '{"collation_confirmed":true,
  "grading":[{"idx":1,"atype":"TERM_LOCK","options":["A","B"]}],
  "graded_items":[{"grade":"A","location":"P5","problem":"…","tibetan_collation":"…","recommended_fix":"…"}]}'   # → AWAIT_ADJUDICATION
python run_agent.py step --ctx n.json --signal '{"adjudications":{"1":"A"},"recite":true}'          # → AWAIT_FINAL_CONFIRM
python run_agent.py step --ctx n.json --signal '{"final_confirm":true,"final_text":"（统稿）","gates":[ …五项认知门控… ]}'   # → AWAIT_DELIVERY
python run_agent.py step --ctx n.json                                    # → AWAIT_GATE_REPORT
python run_agent.py step --ctx n.json                                    # → DONE
```

---

## 9. 相关文档

- 架构与代码↔SKILL 条款映射：`README.md`
- 白话操作手册（含更多示例）：`操作手册_白话版.md`
- 逐节落地审计：`映射审计表.md`
- 规范源（工作流权威）：`tibetan-chinese-collation/SKILL.md`（并存、不改动）
